#include "ps.h"

static long	ft_atol(char *s)
{
	long	n;
	int		sign;

	n = 0;
	sign = 1;
	if (*s == '-')
		sign = -1;
	if (*s == '-' || *s == '+')
		s++;
	while (*s >= '0' && *s <= '9')
		n = n * 10 + (*s++ - '0');
	return (sign * n);
}

static void	ft_tabdel(char **tab)
{
	int	i;

	i = 0;
	while (tab[i])
		free(tab[i++]);
	free(tab);
}

static int	check_atoi(char *s)
{
	int		start;
	int		digits;
	long	n;

	start = 0;
	digits = 0;
	if ((*s == '+' || *s == '-') && ft_isdigit(s[1]) == 1)
		start = 1;
	while (s[start] == '0')
		start++;
	while (ft_isdigit(s[start + digits]))
		digits++;
	if (s[start + digits] != '\0')
		return (-1);
	if (digits > 10)
		return (-1);
	n = ft_atol(s);
	if (n < INT_MIN || n > INT_MAX)
		return (-1);
	return (0);
}

static int	count_argnb(char *arg)
{
	char	**tab;
	int		i;

	tab = ft_split(arg, ' ');
	if (!tab)
		return (-1);
	i = 0;
	while (tab[i])
	{
		if (check_atoi(tab[i]) == -1)
		{
			ft_tabdel(tab);
			return (-1);
		}
		i++;
	}
	ft_tabdel(tab);
	if (i == 0)
		return (-1);
	return (i);
}

static int	*get_argtable(int total, char **argv, int argi, int n)
{
	int		*res;
	char	**tab;
	int		i;

	res = ft_calloc(total, sizeof(int));
	while (argv[argi] && res)
	{
		tab = ft_split(argv[argi], ' ');
		if (!tab)
			break ;
		i = 0;
		while (tab[i])
			res[n++] = ft_atoi(tab[i++]);
		argi++;
		ft_tabdel(tab);
	}
	return (res);
}

static int	check_double(int *tab, int len)
{
	int	i;
	int	j;

	i = -1;
	while (++i < len)
	{
		j = -1;
		while (++j < len)
			if (tab[i] == tab[j] && i != j)
				return (-1);
	}
	return (0);
}

static int	*copy_inttab(int *src, int *dst, int start, int end)
{
	int	i;

	i = -1;
	while (++i < end - start + 1)
		dst[i] = src[i + start];
	return (dst);
}

static int	*bubble_sort(int *tab, int len)
{
	int	i;
	int	j;
	int	tmp;

	i = -1;
	while (++i < len)
	{
		j = i;
		while (++j < len)
		{
			if (tab[j] < tab[i])
			{
				tmp = tab[i];
				tab[i] = tab[j];
				tab[j] = tmp;
			}
		}
	}
	return (tab);
}

static void	initialize(t_ps *ps)
{
	ps->sorted = ft_calloc(ps->total, sizeof(int));
	ps->sorted = copy_inttab(ps->a, ps->sorted, 0, ps->total - 1);
	ps->sorted = bubble_sort(ps->sorted, ps->total);
	ps->min = ps->sorted[0];
	ps->max = ps->sorted[ps->total - 1];
	ps->size_a = ps->total;
	ps->size_b = 0;
	if (ps->a)
		ps->bottom_a = ps->a[ps->total - 1];
	ps->pibon = ft_calloc(1, sizeof(int));
	ps->pibon_len = 1;
	ps->pibon[0] = ps->min;
	ps->pibon_idx = 0;
	ps->top_a = top(ps, 'a');
	ps->top_b = top(ps, 'b');
	ps->ops = ft_calloc(2, sizeof(char));
}

int	parser(int argc, char **argv, t_ps *ps)
{
	int	i;
	int	n;

	ps->total = 0;
	ps->size_a = 0;
	ps->size_b = 0;
	i = debug(ps, argv, argc);
	while (i < argc)
	{
		n = count_argnb(argv[i]);
		if (n == -1)
			ps->total = -1;
		else
			ps->total += n;
		if (ps->total == -1)
			return (-2);
		i++;
	}
	ps->a = get_argtable(ps->total, argv, debug(ps, argv, argc), 0);
	if (ps->a)
		ps->b = ft_calloc(ps->total, sizeof(int));
	if (check_double(ps->a, ps->total) == -1)
		return (-1);
	initialize(ps);
	return (0);
}
