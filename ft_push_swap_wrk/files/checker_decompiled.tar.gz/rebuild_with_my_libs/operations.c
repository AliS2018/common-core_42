#include "ps.h"

/* The *_one helpers are not in the binary: the original repeats the body for
   each stack. */
static void	swap_one(int *s, int t)
{
	int	tmp;

	tmp = s[t];
	s[t] = s[t + 1];
	s[t + 1] = tmp;
}

static void	rotate_one(int *s, int i, int total)
{
	int	tmp;

	tmp = s[i];
	while (++i < total)
		s[i - 1] = s[i];
	s[total - 1] = tmp;
}

static void	reverse_one(int *s, int t, int total)
{
	int	tmp;
	int	i;

	i = total - 1;
	tmp = s[i];
	while (i > t)
	{
		s[i] = s[i - 1];
		i--;
	}
	s[t] = tmp;
}

void	swap_operations(t_ps *ps, char *op)
{
	if (same(op, "sa\n") && ps->size_a > 1)
		swap_one(ps->a, top(ps, 'a'));
	else if (same(op, "sb\n") && ps->size_b > 1)
		swap_one(ps->b, top(ps, 'b'));
	else if (same(op, "ss\n"))
	{
		swap_operations(ps, "sa\n");
		swap_operations(ps, "sb\n");
	}
	visual(ps);
}

void	push_operations(t_ps *ps, char *op)
{
	if (same(op, "pa\n") && ps->size_b > 0)
	{
		ps->a[top(ps, 'a') - 1] = ps->b[top(ps, 'b')];
		ps->b[top(ps, 'b')] = 0;
		ps->size_b--;
		ps->size_a++;
	}
	else if (same(op, "pb\n") && ps->size_a > 0)
	{
		ps->b[top(ps, 'b') - 1] = ps->a[top(ps, 'a')];
		ps->a[top(ps, 'a')] = 0;
		ps->size_a--;
		ps->size_b++;
	}
	ps->top_a = top(ps, 'a');
	ps->top_b = top(ps, 'b');
	visual(ps);
}

void	rotate_operations(t_ps *ps, char *op)
{
	if (same(op, "ra\n") && ps->size_a > 0)
		rotate_one(ps->a, top(ps, 'a'), ps->total);
	else if (same(op, "rb\n") && ps->size_b > 0)
		rotate_one(ps->b, top(ps, 'b'), ps->total);
	else if (same(op, "rr\n"))
	{
		rotate_operations(ps, "ra\n");
		rotate_operations(ps, "rb\n");
	}
	visual(ps);
}

void	reverse_operations(t_ps *ps, char *op)
{
	if (same(op, "rra\n") && ps->size_a > 0)
		reverse_one(ps->a, top(ps, 'a'), ps->total);
	else if (same(op, "rrb\n") && ps->size_b > 0)
		reverse_one(ps->b, top(ps, 'b'), ps->total);
	else if (same(op, "rrr\n"))
	{
		reverse_operations(ps, "rra\n");
		reverse_operations(ps, "rrb\n");
	}
	visual(ps);
}
