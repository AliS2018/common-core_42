#include "ps.h"

/* longest operation is "rra\n": 4 characters, so 5 also compares the '\0' */
int	same(char *s, char *op)
{
	return (ft_strncmp(s, op, 5) == 0);
}

int	top(t_ps *ps, char stack)
{
	if (stack == 'a')
		return (ps->total - ps->size_a);
	if (stack == 'b')
		return (ps->total - ps->size_b);
	return (0);
}

void	ft_free(t_ps *ps)
{
	free(ps->a);
	free(ps->b);
	free(ps->sorted);
	free(ps->pibon);
	free(ps->ops);
}

/* -1: duplicate, -2: not a valid int, -3: bad instruction */
int	error(t_ps *ps, int code)
{
	if (code == -1)
	{
		free(ps->a);
		free(ps->b);
	}
	else if (code == -3)
		ft_free(ps);
	free(ps);
	write(2, "Error\n", 6);
	return (-1);
}

static int	execute(t_ps *ps, char *line)
{
	if (same(line, "sa\n") || same(line, "sb\n") || same(line, "ss\n"))
		swap_operations(ps, line);
	else if (same(line, "pa\n") || same(line, "pb\n"))
		push_operations(ps, line);
	else if (same(line, "ra\n") || same(line, "rb\n") || same(line, "rr\n"))
		rotate_operations(ps, line);
	else if (same(line, "rra\n") || same(line, "rrb\n")
		|| same(line, "rrr\n"))
		reverse_operations(ps, line);
	else
		return (-1);
	return (0);
}

/* Unlike the original, after a bad operation this keeps reading to the end of
   the input, so that get_next_line releases its static buffer. */
int	get_instructions(t_ps *ps)
{
	char	*line;
	int		ret;

	ret = 0;
	line = get_next_line(0);
	while (line)
	{
		if (ret == 0)
			ret = execute(ps, line);
		free(line);
		line = get_next_line(0);
	}
	return (ret);
}

int	check_order_stack(t_ps *ps)
{
	int	i;

	i = ps->top_a;
	while (i < ps->total)
	{
		if (ps->a[i] != ps->sorted[i])
			return (-1);
		i++;
	}
	return (0);
}

int	main(int argc, char **argv)
{
	t_ps	*ps;
	int		ret;

	ps = malloc(sizeof(*ps));
	if (!ps)
		return (-1);
	if (argc > 1)
	{
		ret = parser(argc, argv, ps);
		if (ret == -1 || ret == -2)
			return (error(ps, ret));
		visual(ps);
		if (get_instructions(ps) == -1)
			return (error(ps, -3));
		if (check_order_stack(ps) == 0 && ps->total == ps->size_a)
			ft_printf("OK\n");
		else
			ft_printf("KO\n");
		ft_free(ps);
	}
	free(ps);
	return (0);
}
