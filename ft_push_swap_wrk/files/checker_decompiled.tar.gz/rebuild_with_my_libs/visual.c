#include "ps.h"

/* returns the index of the first number in argv */
int	debug(t_ps *ps, char **argv, int argc)
{
	if (argc < 3 || ft_strncmp(argv[1], "-d", 3) != 0)
	{
		ps->debug = 0;
		return (1);
	}
	ps->debug = 1;
	return (2);
}

static int	nblen(int n)
{
	int	len;

	len = (n <= 0);
	while (n)
	{
		len++;
		n /= 10;
	}
	return (len);
}

static int	is_pibon(int *pibon, int len, int value)
{
	int	i;

	i = -1;
	while (++i < len)
		if (value == pibon[i])
			return (1);
	return (-1);
}

/* column_a and column_b in the binary each carry a copy of this body */
static void	cell(int value, int marked)
{
	int	pad;

	if (marked)
		ft_printf("|     * %d", value);
	else
		ft_printf("|       %d", value);
	pad = 11 - nblen(value);
	while (pad-- != 0)
		ft_putchar_fd(' ', 1);
}

static int	column_a(t_ps *ps, int i)
{
	cell(ps->a[i], ps->bottom_a == ps->a[i] && ps->top_a <= i);
	return (i);
}

static int	column_b(t_ps *ps, int i)
{
	cell(ps->b[i], is_pibon(ps->pibon, ps->pibon_len, ps->b[i]) == 1
		&& ps->top_b <= i);
	ft_printf("|\n");
	return (i);
}

void	visual(t_ps *ps)
{
	int	i;

	i = -1;
	if (ps->debug != 1)
		return ;
	ft_printf(" __________________ __________________ \n");
	ft_printf("|                  |                  |\n");
	ft_printf("|       a          |       b          |\n");
	ft_printf("|__________________|__________________|\n");
	ft_printf("|                  |                  |\n");
	while (i + 1 < ps->total)
		i = column_b(ps, column_a(ps, i + 1));
	ft_printf("|__________________|__________________|\n\n");
}
