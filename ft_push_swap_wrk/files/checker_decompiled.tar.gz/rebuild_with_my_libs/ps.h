/* Reconstructed from checker_linux. Names of fields, parameters and locals are
   guesses from usage; function names come from the binary's symbol table. */
#ifndef PS_H
# define PS_H
# include "libft/libft.h"
# include "get_next_line/get_next_line.h"
# include "ft_printf/ft_printf.h"

typedef struct s_ps
{
	int		total;		/* 0x00 capacity of both arrays */
	int		min;		/* 0x04 */
	int		max;		/* 0x08 */
	int		*a;			/* 0x10 */
	int		*b;			/* 0x18 */
	int		size_a;		/* 0x20 */
	int		size_b;		/* 0x24 */
	int		top_a;		/* 0x28 */
	int		top_b;		/* 0x2c */
	int		bottom_a;	/* 0x30 value at the bottom of a, marked by -d */
	int		*pibon;		/* 0x38 pivots, used by the unused solver */
	int		field_40;	/* 0x40 unknown */
	int		pibon_idx;	/* 0x44 */
	int		pibon_len;	/* 0x48 */
	int		*sorted;	/* 0x50 */
	int		debug;		/* 0x58 set by -d */
	char	*ops;		/* 0x60 used by the unused solver */
}	t_ps;

int		parser(int argc, char **argv, t_ps *ps);
int		check_order_stack(t_ps *ps);
int		get_instructions(t_ps *ps);
int		top(t_ps *ps, char stack);
void	ft_free(t_ps *ps);
int		error(t_ps *ps, int code);

void	swap_operations(t_ps *ps, char *op);
void	push_operations(t_ps *ps, char *op);
void	rotate_operations(t_ps *ps, char *op);
void	reverse_operations(t_ps *ps, char *op);

int		debug(t_ps *ps, char **argv, int argc);
void	visual(t_ps *ps);

int		same(char *s, char *op);

#endif
