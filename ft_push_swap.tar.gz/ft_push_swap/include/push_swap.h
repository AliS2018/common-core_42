/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alavryk <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/26 23:53:03 by alavryk           #+#    #+#             */
/*   Updated: 2026/10/31 04:48:37 by alavryk          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include <stdlib.h>
# include <unistd.h>
# include <limits.h>

typedef struct s_bench
{
	int	total;
	int	sa;
	int	sb;
	int	ss;
	int	ra;
	int	rb;
	int	rr;
	int	rra;
	int	rrb;
	int	rrr;
	int	pa;
	int	pb;
}	t_bench;

typedef enum e_strategy
{
	strat_adaptive,
	strat_simple,
	strat_medium,
	strat_complex,
}	t_strategy;

typedef struct s_config
{
	t_strategy	strat;
	int			bench;
}	t_config;

typedef struct s_node
{
	int		index;
	int		is_above_median;
	struct s_node		*next;
	struct s_node		*prev;
	struct s_node		*target;
}	t_node;

typedef struct s_stack
{
	t_node	*top;
	t_node	*bottom;
	int		size;
}	t_stack;

// --- utils.c ---
char		**free_all(char **arr);
int			*ft_sorted_arr(const int *arr, size_t size);

// --- parser.c & parser_utils.c ---
void		ft_error(void);
size_t		ft_lenstrs(char **str);
int			ft_atol_checker(char *str);
int			check_duplicates(int *arr, size_t size);
int			*ft_parser(int argc, char **argv,
				size_t *size_arr, t_config *config);
// --- stack_utils.c ---
void		ft_update_position(t_stack *stack);

// --- bench.c ---
double		compute_disorder(int *arr, size_t size);

#endif
