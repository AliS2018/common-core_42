#include "checker.h"

/* Returns how many arguments the flag takes */
int	parse_debug_flag(t_checker *ck, int argc, char **argv)
{
	ck->debug = (argc > 2 && ft_strncmp(argv[1], "-d", 3) == 0);
	return (ck->debug);
}

static int	nbr_len(int n)
{
	int	len;

	len = (n <= 0);
	while (n)
	{
		len++;
		n /= 10;
	}
	return (len);
}

/* Stacks are drawn aligned to the bottom, with 0 in the empty rows.
   The value equal to marked gets a '*'. */
static void	print_cell(t_stack *s, int pos, int marked)
{
	int	value;
	int	pad;

	value = 0;
	if (pos >= 0)
		value = s->arr[pos];
	if (pos >= 0 && value == marked)
		ft_printf("|     * %d", value);
	else
		ft_printf("|       %d", value);
	pad = CELL_WIDTH - nbr_len(value);
	while (pad-- > 0)
		ft_putchar_fd(' ', 1);
}

void	print_stacks(t_checker *ck)
{
	t_ps	*ps;
	int		row;

	if (!ck->debug)
		return ;
	ps = ck->ps;
	ft_printf(" __________________ __________________ \n");
	ft_printf("|                  |                  |\n");
	ft_printf("|       a          |       b          |\n");
	ft_printf("|__________________|__________________|\n");
	ft_printf("|                  |                  |\n");
	row = 0;
	while (row < ps->total)
	{
		print_cell(&ps->a, row - (ps->total - ps->a.len), ck->bottom_a);
		print_cell(&ps->b, row - (ps->total - ps->b.len), ck->min);
		ft_printf("|\n");
		row++;
	}
	ft_printf("|__________________|__________________|\n\n");
}
