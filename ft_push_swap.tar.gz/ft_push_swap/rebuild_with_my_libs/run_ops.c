#include "checker.h"

static int	parse_op(char *line, t_op *op)
{
	const char	*names[OP_COUNT] = {"sa\n", "sb\n", "ss\n", "pa\n", "pb\n",
		"ra\n", "rb\n", "rr\n", "rra\n", "rrb\n", "rrr\n"};
	int			i;

	i = 0;
	while (i < OP_COUNT)
	{
		if (ft_strncmp(line, names[i], 5) == 0)
			return (*op = i, 1);
		i++;
	}
	return (0);
}

/* Double operations run as two single ones, so -d shows each step */
static void	run_op(t_checker *ck, t_op op)
{
	if (op == OP_SS)
	{
		run_op(ck, OP_SA);
		run_op(ck, OP_SB);
	}
	else if (op == OP_RR)
	{
		run_op(ck, OP_RA);
		run_op(ck, OP_RB);
	}
	else if (op == OP_RRR)
	{
		run_op(ck, OP_RRA);
		run_op(ck, OP_RRB);
	}
	else
		exec_op(ck->ps, op, 0);
	print_stacks(ck);
}

/* Reads to the end so that get_next_line releases its static buffer */
static void	drain_and_error(t_ps *ps, char *line)
{
	while (line != NULL)
	{
		free(line);
		line = get_next_line(0);
	}
	free_and_exit(ps, NULL, 1);
}

void	read_and_run_ops(t_checker *ck)
{
	char	*line;
	t_op	op;

	line = get_next_line(0);
	while (line != NULL)
	{
		if (!parse_op(line, &op))
			drain_and_error(ck->ps, line);
		run_op(ck, op);
		free(line);
		line = get_next_line(0);
	}
}
