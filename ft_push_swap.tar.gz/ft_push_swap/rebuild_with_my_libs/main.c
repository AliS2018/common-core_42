#include "checker.h"

static void	init_checker(t_checker *ck, int argc, char **argv)
{
	t_ps	*ps;
	int		skip;

	ps = ck->ps;
	skip = parse_debug_flag(ck, argc, argv);
	if (ft_strncmp(argv[1 + skip], "--", 2) == 0)
		free_and_exit(ps, NULL, 1);
	parse_args(argc - skip, argv + skip, ps);
	ps->total = ps->a.len;
	ck->min = ps->a.arr[find_min_pos(&ps->a)];
	ck->bottom_a = ps->a.arr[ps->a.len - 1];
}

int	main(int argc, char **argv)
{
	t_checker	ck;

	if (argc < 2)
		return (0);
	ck.ps = ft_calloc(1, sizeof(t_ps));
	if (!ck.ps)
		return (1);
	init_checker(&ck, argc, argv);
	print_stacks(&ck);
	read_and_run_ops(&ck);
	if (is_sorted(&ck.ps->a) && ck.ps->b.len == 0)
		ft_putendl_fd("OK", 1);
	else
		ft_putendl_fd("KO", 1);
	free_and_exit(ck.ps, NULL, 0);
	return (0);
}
