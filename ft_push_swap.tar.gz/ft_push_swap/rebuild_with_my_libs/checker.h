#ifndef CHECKER_H
# define CHECKER_H

# include "../includes/push_swap.h"
# include "ft_printf/ft_printf.h"

# define CELL_WIDTH 11

typedef struct s_checker
{
	t_ps	*ps;
	int		debug;
	int		min;
	int		bottom_a;
}	t_checker;

/* Operations */
void	read_and_run_ops(t_checker *ck);

/* Debug (-d) */
int		parse_debug_flag(t_checker *ck, int argc, char **argv);
void	print_stacks(t_checker *ck);

#endif
