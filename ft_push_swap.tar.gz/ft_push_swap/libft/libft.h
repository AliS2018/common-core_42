/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   libft.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alavryk <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/02 04:44:15 by alavryk           #+#    #+#             */
/*   Updated: 2026/11/10 18:22:12 by alavryk          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LIBFT_H
# define LIBFT_H

# include <stddef.h> /* Para size_t y NULL */
# include <stdlib.h> /* Para malloc, free y exit */
# include <unistd.h> /* Para write y read */
# include <fcntl.h>  /* Para open, O_RDONLY, etc. */
/* ************************************************************************** */
/*                                ESTRUCTURAS                                 */
/* ************************************************************************** */

/**
 *  Estructura de nodo para listas enlazadas.
 * 
 * @param content Puntero al contenido almacenado en el nodo.
 * @param next Puntero al siguiente nodo de la lista.
 */
typedef struct s_list
{
	void			*content;
	struct s_list	*next;
}	t_list;

/* ************************************************************************** */
/*                         PARTE 1: FUNCIONES DE LIBC                         */
/* ************************************************************************** */

/** Comprueba si el carácter es alfanumérico (letra o número). */
int		ft_isalnum(int c);

/** Comprueba si el carácter es alfabético (letra). */
int		ft_isalpha(int c);

/** Comprueba si el carácter pertenece a la tabla ASCII (0-127). */
int		ft_isascii(int c);

/** Comprueba si el carácter es un dígito (0-9). */
int		ft_isdigit(int c);

/** Comprueba si el carácter es imprimible (incluyendo espacio). */
int		ft_isprint(int c);

/** Convierte una cadena de caracteres a su valor entero (int). */
int		ft_atoi(const char *str);

/** Convierte un carácter a minúscula si es una letra mayúscula. */
int		ft_tolower(int c);

/** Convierte un carácter a mayúscula si es una letra minúscula. */
int		ft_toupper(int c);

/** Rellena los primeros 'n' bytes del área de memoria con ceros. */
void	ft_bzero(void *s, size_t n);

/** Reserva memoria para 'count' elementos de 'size' bytes 
 * e inicializa a cero. */
void	*ft_calloc(size_t count, size_t size);

/** Busca la primera aparición del byte 'c' en 'n' bytes de memoria. */
void	*ft_memchr(const void *s, int c, size_t n);

/** Compara 'n' bytes de dos áreas de memoria. */
int		ft_memcmp(const void *s1, const void *s2, size_t n);

/** Copia 'n' bytes del área de origen al área de destino (sin solapamiento). */
void	*ft_memcpy(void *dst, const void *src, size_t n);

/** Copia 'n' bytes entre áreas de memoria 
 * (maneja solapamiento de manera segura). */
void	*ft_memmove(void *dst, const void *src, size_t len);

/** Llena los primeros 'len' bytes del área de memoria con el byte 'c'. */
void	*ft_memset(void *b, int c, size_t len);

/** Localiza la primera aparición del carácter 'c' en la cadena 's'. */
char	*ft_strchr(const char *s, int c);

/** Duplica la cadena 's1' reservando memoria dinámica con malloc. */
char	*ft_strdup(const char *s1);

/** Concatena 'src' al final de 'dst' garantizando la terminación nula 
 * según 'dstsize'. */
size_t	ft_strlcat(char *dst, const char *src, size_t dstsize);

/** Copia la cadena 'src' en 'dst' garantizando la terminación nula 
 * según 'dstsize'. */
size_t	ft_strlcpy(char *dst, const char *src, size_t dstsize);

/** Calcula la longitud de una cadena de caracteres. */
size_t	ft_strlen(const char *s);

/** Compara como máximo los primeros 'n' caracteres de dos cadenas. */
int		ft_strncmp(const char *s1, const char *s2, size_t n);
int     ft_strcmp(const char *s1, const char *s2);
/** Busca la primera aparición de la subcadena 
 * 'little' en 'big' dentro de 'len' bytes. */
char	*ft_strnstr(const char *big, const char *little, size_t len);

/** Localiza la última aparición del carácter 'c' en la cadena 's'. */
char	*ft_strrchr(const char *s, int c);

/* ************************************************************************** */
/*                     PARTE 2: FUNCIONES ADICIONALES                         */
/* ************************************************************************** */

/** Convierte un número entero (int) a una cadena de caracteres (char *). */
char	*ft_itoa(int n);

/** Escribe el carácter 'c' en el descriptor de archivo (fd) especificado. */
void	ft_putchar_fd(char c, int fd);

/** Escribe un salto de línea seguido de la cadena 's' en el fd especificado. */
void	ft_putendl_fd(char *s, int fd);

/** Escribe un número entero 'n' en el descriptor de archivo (fd) especific.. */
void	ft_putnbr_fd(int n, int fd);

/** Escribe la cadena 's' en el descriptor de archivo (fd) especificado. */
void	ft_putstr_fd(char *s, int fd);

/** Divide la cadena 's' en un array de cadenas utilizando el carácter 'c' 
 * como delimitador. */
char	**ft_split(char const *s, char c);
char	**free_all(char **str);
/** Aplica la función 'f' a cada carácter de la cadena 's' para crear 
 * una nueva cadena. */
char	*ft_strmapi(char const *s, char (*f)(unsigned int, char));

/** Aplica la función 'f' a cada carácter de la cadena 's', 
 * pasando su índice. */
void	ft_striteri(char *s, void (*f)(unsigned int, char*));

/** Une dos cadenas de caracteres ('s1' y 's2') en una nueva cadena 
 * reservada en memoria. */
char	*ft_strjoin(char const *s1, char const *s2);

/** Elimina los caracteres indicados en 'set' del principio y 
 * final de la cadena 's1'. */
char	*ft_strtrim(char const *s1, char const *set);

/** Crea una subcadena a partir de 's', empezando en el índice 'start' 
 * con longitud 'len'. */
char	*ft_substr(char const *s, unsigned int start, size_t len);

/* ************************************************************************** */
/*                         PARTE BONUS: LISTAS ENLAZADAS                      */
/* ************************************************************************** */

/** Añade el nodo 'new' al final de la lista enlazada. */
void	ft_lstadd_back(t_list **lst, t_list *new);

/** Añade el nodo 'new' al principio de la lista enlazada. */
void	ft_lstadd_front(t_list **lst, t_list *new);

/** Elimina y libera el nodo 'lst' aplicando la función 'del' a su contenido. */
void	ft_lstdelone(t_list *lst, void (*del)(void *));

/** Elimina y libera el nodo 'lst' y todos sus sucesores 
 * mediante la función 'del'. */
void	ft_lstclear(t_list **lst, void (*del)(void *));

/** Aplica la función 'f' al contenido de cada nodo de la lista. */
void	ft_lstiter(t_list *lst, void (*f)(void *));

/** Devuelve el último nodo de la lista enlazada. */
t_list	*ft_lstlast(t_list *lst);

/** Genera una nueva lista aplicando la función 'f' al contenido de cada 
 * nodo de 'lst'. */
t_list	*ft_lstmap(t_list *lst, void *(*f)(void *), void (*del)(void *));

/** Crea un nuevo nodo asignando memoria e inicializando 'content' y 'next'. */
t_list	*ft_lstnew(void *content);

/** Cuenta el número total de nodos en la lista enlazada. */
int		ft_lstsize(t_list *lst);

#endif
