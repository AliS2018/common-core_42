/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   alg_simple.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alavryk <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/11/10 16:34:17 by alavryk           #+#    #+#             */
/*   Updated: 2026/11/10 16:34:52 by alavryk          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"



static int	ft_get_position(t_stack *stack, int value)
{
	int	i;

	i = 0;
	while (i < stack->size)
	{
		if (stack->arr[i] == value)
			return (i);
		i++;
	}
	return (-1);
}

void	alg_simple(t_stack *a, t_stack *b)
{
	int	target;
	int	pos;

	if (!a || !b || a->size < 2)
		return ;
	target = 0;
	while (a->size > 1)
	{
		pos = ft_get_position(a, target);
		if (pos == -1)
			break ;
		
		// Mientras el elemento superior no sea el target, rotamos
		while (a->arr[0] != target)
		{
			if (pos <= a->size / 2)
				ra(a);
			else
				rra(a);
		}
		pb(a, b);
		target++;
	}
	while (b->size > 0)
		pa(a, b);
}
