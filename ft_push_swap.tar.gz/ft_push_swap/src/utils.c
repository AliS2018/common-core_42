/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alavryk <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/26 23:38:43 by alavryk           #+#    #+#             */
/*   Updated: 2026/10/31 04:11:24 by alavryk          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"
#include "libft.h"

int	*ft_sorted_arr(const int *arr, size_t size)
{
	int	i;
	int	j;
	int	*srt_arr;

	if (!arr)
		return (NULL);
	srt_arr = malloc(sizeof(int) * size);
	i = -1;
	while (++i < (int)size)
		srt_arr[i] = arr[i];
	i = -1;
	while (++i < (int)size - 1)
	{
		j = i;
		while (++j < (int)size)
		{
			if (srt_arr[i] > srt_arr[j])
			{
				srt_arr[i] = srt_arr[i] ^ srt_arr[j];
				srt_arr[j] = srt_arr[i] ^ srt_arr[j];
				srt_arr[i] = srt_arr[i] ^ srt_arr[j];
			}
		}
	}
	return (srt_arr);
}
