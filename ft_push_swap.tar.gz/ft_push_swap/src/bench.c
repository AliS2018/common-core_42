/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bench.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alavryk <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/30 08:38:58 by alavryk           #+#    #+#             */
/*   Updated: 2026/11/10 21:43:51 by alsadyko         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

static	t_op_counter *g_counter;

void	init_op_counter(t_op_counter *counter)
{
	g_counter = counter;
}

t_op_counter	*get_op_counter(void)
{
	return (g_counter);
}

static void    ft_count(char *op)
{
	if (g_counter)
	{
		if (ft_strcmp(op, "ra") == 0)
			g_counter->ra++;
		else if (ft_strcmp(op, "rb") == 0)
			g_counter->rb++;
		else if (ft_strcmp(op, "sb") == 0)
			g_counter->sb++;
		else if (ft_strcmp(op, "pa") == 0)
			g_counter->pa++;
		else if (ft_strcmp(op, "pb") == 0)
			g_counter->pb++;
		else if (ft_strcmp(op, "rra") == 0)
			g_counter->rra++;
		else if (ft_strcmp(op, "rrb") == 0)
			g_counter->rrb++;
		else if (ft_strcmp(op, "rrr") == 0)
			g_counter->rrr++;
		else if (ft_strcmp(op, "rr") == 0)
			g_counter->rr++;
		else if (ft_strcmp(op, "sa") == 0)
			g_counter->sa++;
		g_counter->total++;
	}
	ft_putendl_fd(op, 1);
}

static int	ft_count_combo(char *op_pre, char *op)
{
	size_t	len_op;
	size_t	len_op_pre;
	
	len_op = ft_strlen(op);
	len_op_pre = ft_strlen(op_pre);
	if((len_op == len_op_pre) && !ft_strncmp(op, op_pre, len_op - 1)
			&& op[len_op -1] != op_pre[len_op - 1])
	{
		if (op[0] == 'r' && len_op == 2)
			ft_count("rr");
		else if (op[0] == 'r' && len_op == 3)
			ft_count("rrr");
		else if (op[0] == 's' && len_op == 2)
			ft_count("ss");
		return (1);
	}
	return (0);
}

void	op_print(char *op)
{
	static char	*op_pre;
	
	if (!op)
	{
		if (op_pre)
		{
			ft_count(op_pre);
			op_pre = NULL;
		}
		return ;
	}
	else if (!op_pre)
	{
		op_pre = op;
		return ;
	}
	if (ft_count_combo(op_pre, op))
		op_pre = NULL;
	else
	{
		ft_count(op_pre);
		op_pre = op;
	}
}
