/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bench.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alavryk <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/30 08:38:58 by alavryk           #+#    #+#             */
/*   Updated: 2026/10/31 12:16:09 by alavryk          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

double	compute_disorder(int *arr, size_t size)
{
	int	i;
	int	count;

	if (!arr || size == 1)
		return (0);
	i = -1;
	count = 0;
	while (++i < (int)size - 1)
	{
		if (arr[i] > arr[i + 1])
			count++;
	}
	return (count / (double)(size - 1));
}
