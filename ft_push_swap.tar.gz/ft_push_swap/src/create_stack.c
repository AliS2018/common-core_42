/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   create_stack.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alavryk <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/11/07 23:11:09 by alavryk           #+#    #+#             */
/*   Updated: 2026/11/09 17:09:51 by alavryk          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

static int	*value_to_index(int *arr, int *srt, size_t size)
{
	size_t	i;
	size_t	j;
	int		*new;

	new = malloc(size * sizeof(int));
	if (!new)
		return (NULL);
	i = 0;
	while (i < size)
	{
		j = 0;
		while (j < size)
		{
			if (arr[i] == srt[j])
			{
				new[i] = j;
				break ;
			}
			j++;
		}
		i++;
	}
	free(arr);
	free(srt);
	return (new);
}

static int	*sorted_arr(int	*arr, size_t	size)
{
	int	i;
	int	j;
	int	*srt;

	srt = (int *)malloc((int)size * sizeof (int));
	if (!srt)
		return (free(arr), NULL);
	i = -1;
	while (++i < (int)size)
		srt[i] = arr[i];
	i = -1;
	while (++i < (int)size - 1)
	{
		j = i;
		while (++j < (int)size)
		{
			if (srt[i] > srt[j])
			{
				srt[i] = srt[i] ^ srt[j];
				srt[j] = srt[i] ^ srt[j];
				srt[i] = srt[i] ^ srt[j];
			}
		}
	}
	return (srt);
}

t_stack	*create_stack(int *arr, size_t size)
{
	int		*srt;
	int		*new_vl_idx;
	t_stack	*stack;

	stack = malloc(sizeof(t_stack));
	if (!stack)
		return (free(arr), NULL);
	if (!arr)
	{
		stack->arr = malloc(size * sizeof(int));
		if (!stack->arr)
			return (free(stack), NULL);
		stack->size = 0;
		return (stack);
	}
	srt = sorted_arr(arr, size);
	if (!srt)
		return (free(stack), NULL);
	new_vl_idx = value_to_index(arr, srt, size);
	if (!new_vl_idx)
		return (free(stack), NULL);
	stack->arr = new_vl_idx;
	stack->size = size;
	return (stack);
}
