/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   op_rotate_and_reverse.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alavryk <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/11/09 15:24:53 by alavryk           #+#    #+#             */
/*   Updated: 2026/11/09 16:37:08 by alavryk          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

#include "push_swap.h"

void	ra(t_stack *a)
{
	int	tmp;

	if (!a || a->size < 2)
		return ;
	tmp = a->arr[0];
	ft_memmove(&a->arr[0], &a->arr[1], sizeof(int) * (a->size - 1));
	a->arr[a->size - 1] = tmp;
	op_print("ra");
}

void	rb(t_stack *b)
{
	int	tmp;

	if (!b || b->size < 2)
		return ;
	tmp = b->arr[0];
	ft_memmove(&b->arr[0], &b->arr[1], sizeof(int) * (b->size - 1));
	b->arr[b->size - 1] = tmp;
	op_print("rb");
}

void	rra(t_stack *a)
{
	int	tmp;

	if (!a || a->size < 2)
		return ;
	tmp = a->arr[a->size - 1];
	ft_memmove(&a->arr[1], &a->arr[0], sizeof(int) * (a->size - 1));
	a->arr[0] = tmp;
	op_print("rra");
}

void	rrb(t_stack *b)
{
	int	tmp;

	if (!b || b->size < 2)
		return ;
	tmp = b->arr[b->size - 1];
	ft_memmove(&b->arr[1], &b->arr[0], sizeof(int) * (b->size - 1));
	b->arr[0] = tmp;
	op_print("rrb");
}
