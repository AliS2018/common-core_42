#include "push_swap.h"
#include <stdio.h>
#include "libft.h"

int	main(int argc, char **argv)
{
	int		*arr;
	size_t	size;
	size_t	i;
	t_config	config;
	int		*srt;
	config.bench = 0;
	config.strat = strat_adaptive;
	if (argc < 2)
		return (0);
	arr = ft_parser(argc, argv, &size, &config);
	printf("compute_disorder = %.2lf", compute_disorder(arr, size));
	srt = ft_sorted_arr(arr, size);
	printf("--- PARSER OK ---\n");
	printf("Bench: %d | Strategy: %d | Total elements: %zu\n", 
		config.bench, config.strat, size);
	i = 0;
	while (i < size)
	{
		printf("srt[%zu] = %d\n", i, srt[i]);
		i++;
	}
	free(srt);
	free(arr);
	return (0);
}
