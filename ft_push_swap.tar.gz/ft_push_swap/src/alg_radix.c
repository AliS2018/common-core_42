/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   alg_radix.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alavryk <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/11/10 16:25:15 by alavryk           #+#    #+#             */
/*   Updated: 2026/11/10 16:33:22 by alavryk          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

static int get_mx_bit(int size)
{
    int bits = 0;
    int max_val;

    if (size <= 0)
        return (0);
    max_val = size - 1;
    while ((max_val >> bits) != 0)
        bits++;
    return (bits);
}

void    alg_radix2(t_stack *a, t_stack *b)
{
    int     mx_bit;
    int     j;
    int     k;
    int     initial_size;

    mx_bit = get_mx_bit(a->size);
    initial_size = a->size; 
    j = -1;
    while (++j < mx_bit)
    {
        k = 0;
        while (k < initial_size)
        {
            if (((a->arr[0] >> j) & 1) == 0)
                pb(a, b);
            else
                ra(a);
            k++;
        }
        while (b->size > 0)
		pa(a, b);
    }
}
