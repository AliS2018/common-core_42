/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser_utils.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alavryk <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/26 23:58:39 by alavryk           #+#    #+#             */
/*   Updated: 2026/11/10 20:13:44 by alavryk          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

size_t	ft_lenstrs(char **str)
{
	size_t	len;

	len = 0;
	while (str[len])
		len++;
	return (len);
}

int	ft_atol_checker(char *str)
{
	long	num;
	int		sign;
	int		i;

	if (!str || !*str)
		ft_error();
	num = 0;
	sign = 1;
	i = 0;
	if (str[i] == '-' || str[i] == '+')
		if (str[i++] == '-')
			sign = -1;
	if (!str[i])
		ft_error();
	while (str[i])
	{
		if (str[i] < '0' || str[i] > '9')
			ft_error();
		num = num * 10 + (str[i++] - '0');
		if (num > 2147483647L + (sign == -1))
			ft_error();
	}
	return ((int)(num * sign));
}

int	check_duplicates(int *arr, size_t size)
{
	size_t	i;
	size_t	j;

	i = 0;
	while (i < size)
	{
		j = i + 1;
		while (j < size)
		{
			if (arr[i] == arr[j])
				return (1);
			j++;
		}
		i++;
	}
	return (0);
}

double	compute_disorder(int *arr, size_t size)
{
	int	i;
	int	count;

	if (!arr || size == 1)
		return (0);
	i = -1;
	count = 0;
	while (++i < (int)size - 1)
	{
		if (arr[i] > arr[i + 1])
			count++;
	}
	return (count / (double)(size - 1));
}

