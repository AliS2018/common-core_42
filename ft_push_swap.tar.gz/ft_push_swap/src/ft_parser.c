/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parser.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alavryk <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/26 23:59:13 by alavryk           #+#    #+#             */
/*   Updated: 2026/10/31 05:17:51 by alavryk          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"
#include "libft.h"

void	ft_error(void)
{
	write(2, "Error\n", 6);
	exit(1);
}

static int	ft_parse_flags(int argc, char **argv, t_config *config)
{
	int	i;

	i = 1;
	while (i < argc && (argv[i][0] == '-' && argv[i][1] == '-'))
	{
		if (ft_strncmp(argv[i], (const char *)"--bench", 8) == 0)
			config->bench = 1;
		else if (ft_strncmp(argv[i], "--simple", 9) == 0)
			config->strat = strat_simple;
		else if (ft_strncmp(argv[i], "--medium", 9) == 0)
			config->strat = strat_medium;
		else if (ft_strncmp(argv[i], "--complex", 10) == 0)
			config->strat = strat_complex;
		else if (ft_strncmp(argv[i], "--adaptive", 11) == 0)
			config->strat = strat_adaptive;
		else
			ft_error();
		i++;
	}
	return (i);
}

static int	*ft_realloc_arr(int *arr, size_t *size_arr, char **str)
{
	int		*res;
	size_t	j;

	res = malloc(sizeof(int) * (*size_arr + ft_lenstrs(str)));
	if (!res)
	{
		free_all(str);
		if (arr)
			free(arr);
		ft_error();
	}
	j = 0;
	while (j < *size_arr)
	{
		res[j] = arr[j];
		j++;
	}
	if (arr)
		free(arr);
	return (res);
}

static int	*ft_process_arg(int *arr, size_t *size_arr, char *arg)
{
	char	**str;
	size_t	j;

	str = ft_split(arg, ' ');
	if (!str)
	{
		if (arr)
			free(arr);
		ft_error();
	}
	arr = ft_realloc_arr(arr, size_arr, str);
	j = 0;
	while (str[j])
		arr[(*size_arr)++] = ft_atol_checker(str[j++]);
	free_all(str);
	return (arr);
}

int	*ft_parser(int argc, char **argv, size_t *size_arr, t_config *config)
{
	int		i;
	int		*arr;
	size_t	s_idx;

	arr = NULL;
	*size_arr = 0;
	s_idx = ft_parse_flags(argc, argv, config);
	if ((int)s_idx >= argc)
		ft_error();
	i = s_idx - 1;
	while (++i < argc)
		arr = ft_process_arg(arr, size_arr, argv[i]);
	if (check_duplicates(arr, *size_arr))
	{
		free(arr);
		ft_error();
	}
	return (arr);
}
